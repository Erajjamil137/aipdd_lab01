"""Task 7 - Real-time webcam multi-object detection dashboard.

Keys:  q = quit   |   s = save current frame to captures/
Usage: python live_detection.py [--source 0] [--model yolov8n.pt] [--conf 0.4]
"""
import argparse
import os
import time
from datetime import datetime

import cv2
from ultralytics import YOLO


def open_capture(source=0):
    """Open webcam index (int) or a video file path."""
    if isinstance(source, str) and source.isdigit():
        source = int(source)
    cap = cv2.VideoCapture(source)                       # 1. cv2.VideoCapture(0)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video source: {source}")
    return cap


def draw_fps(frame, fps):
    """Render FPS in the top-left corner."""
    text = f"FPS: {fps:.1f}"
    cv2.rectangle(frame, (0, 0), (150, 34), (0, 0, 0), -1)
    cv2.putText(frame, text, (8, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                (0, 255, 0), 2, cv2.LINE_AA)
    return frame


def save_frame(frame, folder="captures"):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".jpg")
    cv2.imwrite(path, frame)
    print("Saved:", path)


def run(source=0, model_path="yolov8n.pt", conf=0.4, imgsz=640):
    model = YOLO(model_path)
    cap = open_capture(source)
    fps, prev = 0.0, time.perf_counter()
    try:
        while True:                                       # 2. continuous capture loop
            ok, frame = cap.read()
            if not ok:
                print("No frame received - stream ended.")
                break

            result = model.predict(frame, conf=conf, imgsz=imgsz, verbose=False)[0]
            annotated = result.plot()                     # boxes + labels

            now = time.perf_counter()                     # 3. FPS (smoothed)
            inst = 1.0 / max(now - prev, 1e-6)
            fps = inst if fps == 0 else 0.9 * fps + 0.1 * inst
            prev = now
            draw_fps(annotated, fps)

            cv2.imshow("YOLO Live Detection  (q=quit, s=save)", annotated)

            key = cv2.waitKey(1) & 0xFF                   # 4. key handler
            if key == ord("q"):
                break
            if key == ord("s"):
                save_frame(annotated)
    finally:
        cap.release()                                     # 5. cleanup
        cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default="0", help="webcam index or video file")
    parser.add_argument("--model", default="yolov8n.pt")
    parser.add_argument("--conf", type=float, default=0.4)
    parser.add_argument("--imgsz", type=int, default=640)
    args = parser.parse_args()
    run(args.source, args.model, args.conf, args.imgsz)


if __name__ == "__main__":
    main()
