"""Task 5 - Retail inventory: class-filtered YOLO detection + item counting.

Keeps only the target class IDs (COCO: 39 = bottle, 47 = apple), counts items
with confidence >= 0.50 and prints an on-image summary banner.
"""
import argparse
import os

import cv2
import matplotlib.pyplot as plt
from ultralytics import YOLO

from utils import OUT_DIR, load_image


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", default="shelf.jpg", help="crowded retail shelf image")
    parser.add_argument("--model", default="yolov8m.pt")
    parser.add_argument("--classes", type=int, nargs="+", default=[39],
                        help="COCO target class IDs (39=bottle, 47=apple)")
    parser.add_argument("--conf", type=float, default=0.50)
    args, _ = parser.parse_known_args()

    img = load_image(args.image, fallback="bus.jpg")
    model = YOLO(args.model)

    # 1. Run YOLO on everything with a low threshold, filter manually afterwards
    res = model.predict(img, conf=0.10, verbose=False)[0]

    # 2-3. Programmatic class + confidence filtering
    targets = []
    for b in res.boxes:
        cid, conf = int(b.cls[0]), float(b.conf[0])
        if cid in args.classes and conf >= args.conf:
            x1, y1, x2, y2 = (int(v) for v in b.xyxy[0].tolist())
            targets.append((x1, y1, x2, y2, conf, res.names[cid]))

    names = sorted({res.names[c] for c in args.classes})
    label = "/".join(names)
    print(f"Detected {len(res.boxes)} objects total, kept {len(targets)} "
          f"target item(s) [{label}] with conf >= {args.conf}")

    # 4. Overlay boxes + banner
    out = img.copy()
    for x1, y1, x2, y2, conf, name in targets:
        cv2.rectangle(out, (x1, y1), (x2, y2), (0, 220, 0), 2)
        cv2.putText(out, f"{name} {conf:.2f}", (x1, max(15, y1 - 5)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 220, 0), 1, cv2.LINE_AA)
    banner = f"Target Item Count: {len(targets)}"
    cv2.rectangle(out, (0, 0), (out.shape[1], 45), (0, 0, 0), -1)
    cv2.putText(out, banner, (10, 32), cv2.FONT_HERSHEY_SIMPLEX, 1.0,
                (0, 255, 255), 2, cv2.LINE_AA)

    path = os.path.join(OUT_DIR, "task5_result.png")
    cv2.imwrite(path, out)
    print("Saved:", path)
    plt.figure(figsize=(11, 8))
    plt.imshow(cv2.cvtColor(out, cv2.COLOR_BGR2RGB))
    plt.title(f"Task 5: {banner}")
    plt.axis("off")
    plt.show()


if __name__ == "__main__":
    main()
