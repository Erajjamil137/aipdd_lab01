"""Shared helpers for LAB 03 (AI-316).

load_image(): loads your image, or (if the path is missing) downloads a small
sample image so every script still runs end-to-end.
"""
import os
import urllib.request

import cv2

OUT_DIR = "outputs"
SAMPLE_DIR = "samples"
ASSETS_URL = ("https://raw.githubusercontent.com/ultralytics/ultralytics/"
              "main/ultralytics/assets/")

os.makedirs(OUT_DIR, exist_ok=True)


def load_image(path=None, fallback="bus.jpg", flags=cv2.IMREAD_COLOR):
    """Read an image with cv2.imread. Falls back to a downloaded sample."""
    if path:
        if not os.path.exists(path):
            print(f"[!] '{path}' not found -> using sample image '{fallback}'")
        else:
            img = cv2.imread(path, flags)
            if img is None:
                raise ValueError(f"cv2.imread could not decode: {path}")
            return img

    os.makedirs(SAMPLE_DIR, exist_ok=True)
    local = os.path.join(SAMPLE_DIR, fallback)
    if not os.path.exists(local):
        print(f"[i] Downloading sample image {fallback} ...")
        try:
            urllib.request.urlretrieve(ASSETS_URL + fallback, local)
        except Exception as exc:  # no internet
            raise FileNotFoundError(
                f"No image given and download failed ({exc}). "
                f"Pass your own image with --image path/to/img.jpg") from exc
    return cv2.imread(local, flags)
