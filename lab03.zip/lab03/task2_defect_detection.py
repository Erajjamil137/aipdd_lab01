"""Task 2 - Industrial defect (rust) detection via colour spaces + thresholding.

BGR -> HSV / LAB, cv2.inRange mask, cv2.threshold refinement, cv2.bitwise_and.
If no image is given, a synthetic metal plate with rust patches is generated.
"""
import argparse
import os

import cv2
import matplotlib.pyplot as plt
import numpy as np

from utils import OUT_DIR

# HSV bounds for rust / orange-brown (OpenCV: H 0-179, S 0-255, V 0-255)
LOWER_HSV = np.array([5, 100, 50])
UPPER_HSV = np.array([25, 255, 255])


def make_synthetic_product(h=480, w=640, seed=0):
    rng = np.random.default_rng(seed)
    img = np.full((h, w, 3), (170, 170, 175), np.uint8)               # grey metal
    cv2.rectangle(img, (50, 50), (w - 50, h - 50), (150, 150, 155), -1)
    for cx, cy in [(90, 90), (w - 90, 90), (90, h - 90), (w - 90, h - 90)]:
        cv2.circle(img, (cx, cy), 18, (110, 110, 115), -1)             # bolts
    for cx, cy, a, b in [(220, 200, 55, 30), (430, 300, 70, 40), (300, 380, 35, 25)]:
        cv2.ellipse(img, (cx, cy), (a, b), int(rng.integers(0, 180)), 0, 360,
                    (30, 85, 165), -1)                                  # rust (BGR)
    img = cv2.GaussianBlur(img, (7, 7), 0)
    noise = rng.normal(0, 5, img.shape)
    return np.clip(img + noise, 0, 255).astype(np.uint8)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", default=None, help="industrial product image")
    args, _ = parser.parse_known_args()

    if args.image and os.path.exists(args.image):
        bgr = cv2.imread(args.image)
    else:
        print("[i] No image supplied -> using synthetic rusted metal plate")
        bgr = make_synthetic_product()

    # 1. Colour-space conversion
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB)

    # 2-3. Range mask -> smooth -> binary threshold -> morphology
    mask = cv2.inRange(hsv, LOWER_HSV, UPPER_HSV)
    blurred = cv2.GaussianBlur(mask, (5, 5), 0)
    _, refined = cv2.threshold(blurred, 127, 255, cv2.THRESH_BINARY)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    refined = cv2.morphologyEx(refined, cv2.MORPH_OPEN, kernel)
    refined = cv2.morphologyEx(refined, cv2.MORPH_CLOSE, kernel)

    # 4. Isolate defect
    isolated = cv2.bitwise_and(bgr, bgr, mask=refined)

    area = 100.0 * np.count_nonzero(refined) / refined.size
    contours, _ = cv2.findContours(refined, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    print(f"Defect area: {area:.2f}% of image | regions found: {len(contours)}")

    # Plot grid
    H, S, V = cv2.split(hsv)
    L, A, B = cv2.split(lab)
    panels = [
        ("Original (BGR->RGB)", cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB), None),
        ("HSV - Hue", H, "hsv"), ("HSV - Saturation", S, "gray"), ("HSV - Value", V, "gray"),
        ("LAB - L", L, "gray"), ("LAB - a", A, "gray"), ("LAB - b", B, "gray"),
        ("inRange mask", mask, "gray"),
        ("Refined mask (threshold+morph)", refined, "gray"),
        ("Isolated defect (bitwise_and)", cv2.cvtColor(isolated, cv2.COLOR_BGR2RGB), None),
    ]
    fig, axes = plt.subplots(3, 4, figsize=(16, 11))
    for ax, (title, img, cmap) in zip(axes.ravel(), panels):
        ax.imshow(img, cmap=cmap)
        ax.set_title(title)
        ax.set_xlabel("x (px)")
        ax.set_ylabel("y (px)")
    for ax in axes.ravel()[len(panels):]:
        ax.axis("off")
    fig.suptitle(f"Task 2: Rust detection  |  HSV range {LOWER_HSV.tolist()} - "
                 f"{UPPER_HSV.tolist()}  |  defect area {area:.2f}%", fontsize=13)
    plt.tight_layout()
    out = os.path.join(OUT_DIR, "task2_result.png")
    plt.savefig(out, dpi=130)
    print("Saved:", out)
    plt.show()


if __name__ == "__main__":
    main()
