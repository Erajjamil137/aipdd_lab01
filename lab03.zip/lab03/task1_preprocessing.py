"""Task 1 - Automated preprocessing pipeline for traffic camera footage.

Steps: imread -> letterbox resize to 640x640 (aspect ratio kept) ->
normalise [0,255] -> [0.0,1.0] -> side-by-side matplotlib display + tensor stats.
"""
import argparse
import os

import cv2
import matplotlib.pyplot as plt
import numpy as np

from utils import OUT_DIR, load_image

TARGET = 640


def letterbox(img, size=TARGET, color=(114, 114, 114)):
    """Resize keeping aspect ratio, then pad to a size x size square."""
    h, w = img.shape[:2]
    scale = min(size / h, size / w)
    new_w, new_h = int(round(w * scale)), int(round(h * scale))
    interp = cv2.INTER_AREA if scale < 1 else cv2.INTER_LINEAR
    resized = cv2.resize(img, (new_w, new_h), interpolation=interp)

    top = (size - new_h) // 2
    bottom = size - new_h - top
    left = (size - new_w) // 2
    right = size - new_w - left
    padded = cv2.copyMakeBorder(resized, top, bottom, left, right,
                                cv2.BORDER_CONSTANT, value=color)
    return padded, scale, (left, top)


def normalize(img_uint8):
    """uint8 [0,255] -> float32 [0.0,1.0]."""
    return img_uint8.astype(np.float32) / 255.0


def describe(name, arr):
    print(f"{name:<22} shape={arr.shape}  dtype={arr.dtype}  "
          f"min={arr.min():.4f}  max={arr.max():.4f}  mean={arr.mean():.4f}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", default="traffic.jpg",
                        help="high-resolution traffic scene image")
    args, _ = parser.parse_known_args()

    # 1. Load
    bgr = load_image(args.image, fallback="bus.jpg")
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)

    # 2. Letterbox resize 640x640
    letter, scale, (padx, pady) = letterbox(rgb)

    # 3. Normalise
    norm = normalize(letter)
    tensor = np.transpose(norm, (2, 0, 1))[None]  # (1,3,640,640) NCHW model input

    print("=== Pixel tensor statistics ===")
    describe("Original (uint8)", rgb)
    describe("Letterboxed (uint8)", letter)
    describe("Normalised (float32)", norm)
    describe("Model tensor NCHW", tensor)
    print(f"scale={scale:.4f}, padding (left,top)=({padx},{pady})")

    # 4. Display
    fig, axes = plt.subplots(1, 3, figsize=(16, 5.5))
    axes[0].imshow(rgb)
    axes[0].set_title(f"Original ({rgb.shape[1]}x{rgb.shape[0]})")
    axes[1].imshow(letter)
    axes[1].set_title("Letterboxed 640x640 (uint8)")
    axes[2].imshow(norm)
    axes[2].set_title(f"Normalised float32 [{norm.min():.1f}, {norm.max():.1f}]")
    for ax in axes:
        ax.set_xlabel("Width (pixels)")
        ax.set_ylabel("Height (pixels)")
    axes[2].text(8, 625, f"shape={norm.shape}  min={norm.min():.2f}  max={norm.max():.2f}",
                 color="yellow", fontsize=9, backgroundcolor="black")
    fig.suptitle("Task 1: Traffic camera preprocessing pipeline", fontsize=14)
    plt.tight_layout()
    out = os.path.join(OUT_DIR, "task1_result.png")
    plt.savefig(out, dpi=150)
    print("Saved:", out)
    plt.show()


if __name__ == "__main__":
    main()
