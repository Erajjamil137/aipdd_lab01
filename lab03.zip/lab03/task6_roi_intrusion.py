"""Task 6 - Security intrusion alerting with a polygon ROI.

YOLO person detection -> bbox centroid -> cv2.pointPolygonTest against ROI.
ROI red + "INTRUSION DETECTED" if any person centroid is inside, else green.
"""
import argparse
import os

import cv2
import matplotlib.pyplot as plt
import numpy as np
from ultralytics import YOLO

from utils import OUT_DIR, load_image

# default ROI as fractions of (width, height) so it fits any image size
DEFAULT_ROI = [(0.15, 0.35), (0.85, 0.35), (0.95, 0.95), (0.05, 0.95)]


def parse_roi(text, w, h):
    """--roi "100,200;400,200;400,500;100,500" in pixel coordinates."""
    if not text:
        return np.array([(int(x * w), int(y * h)) for x, y in DEFAULT_ROI], np.int32)
    return np.array([tuple(int(v) for v in p.split(",")) for p in text.split(";")], np.int32)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", default="surveillance.jpg")
    parser.add_argument("--model", default="yolov8n.pt")
    parser.add_argument("--roi", default=None, help='pixel polygon "x,y;x,y;x,y;..."')
    parser.add_argument("--conf", type=float, default=0.40)
    args, _ = parser.parse_known_args()

    img = load_image(args.image, fallback="bus.jpg")
    h, w = img.shape[:2]
    roi = parse_roi(args.roi, w, h)                                     # 1. ROI polygon

    res = YOLO(args.model).predict(img, conf=args.conf, classes=[0], verbose=False)[0]

    intrusion = False
    out = img.copy()
    for b in res.boxes:                                                  # 2. persons
        x1, y1, x2, y2 = (int(v) for v in b.xyxy[0].tolist())
        xc, yc = (x1 + x2) // 2, (y1 + y2) // 2                          # centroid
        inside = cv2.pointPolygonTest(roi.reshape(-1, 1, 2), (float(xc), float(yc)), False) >= 0  # 3.
        intrusion |= inside
        color = (0, 0, 255) if inside else (255, 200, 0)
        cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
        cv2.circle(out, (xc, yc), 5, color, -1)
        cv2.putText(out, f"person {float(b.conf[0]):.2f}", (x1, max(15, y1 - 5)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1, cv2.LINE_AA)

    # 4. ROI colour + alert text
    roi_color = (0, 0, 255) if intrusion else (0, 255, 0)                # BGR red / green
    cv2.polylines(out, [roi.reshape(-1, 1, 2)], True, roi_color, 3)
    status = "INTRUSION DETECTED" if intrusion else "Area Clear"
    cv2.rectangle(out, (0, 0), (w, 50), (0, 0, 0), -1)
    cv2.putText(out, status, (10, 36), cv2.FONT_HERSHEY_SIMPLEX, 1.1, roi_color, 3, cv2.LINE_AA)

    print(f"Persons detected: {len(res.boxes)} | status: {status}")
    path = os.path.join(OUT_DIR, "task6_result.png")
    cv2.imwrite(path, out)
    print("Saved:", path)
    plt.figure(figsize=(9, 10))
    plt.imshow(cv2.cvtColor(out, cv2.COLOR_BGR2RGB))
    plt.title(f"Task 6: {status}")
    plt.axis("off")
    plt.show()


if __name__ == "__main__":
    main()
