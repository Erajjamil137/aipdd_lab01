"""Task 3 - Noise reduction + edge detection for medical imaging.

Grayscale load -> (add synthetic noise) -> Gaussian vs Median filtering ->
Sobel X/Y + gradient magnitude -> Canny with tuned hysteresis thresholds ->
quantitative comparison table (PSNR, edge precision/recall/F1 vs clean image).
"""
import argparse
import csv
import os

import cv2
import matplotlib.pyplot as plt
import numpy as np

from utils import OUT_DIR


def make_phantom(size=512):
    """Synthetic chest-like phantom, used when no scan is supplied."""
    img = np.zeros((size, size), np.uint8)
    cv2.ellipse(img, (256, 256), (210, 240), 0, 0, 360, 110, -1)       # body
    cv2.ellipse(img, (180, 250), (70, 130), 0, 0, 360, 40, -1)          # lung L
    cv2.ellipse(img, (332, 250), (70, 130), 0, 0, 360, 40, -1)          # lung R
    cv2.circle(img, (256, 290), 28, 200, -1)                            # spine
    cv2.circle(img, (256, 330), 40, 160, -1)                            # heart-ish
    return cv2.GaussianBlur(img, (3, 3), 0)


def add_noise(img, sigma=18, sp=0.03, seed=0):
    rng = np.random.default_rng(seed)
    noisy = np.clip(img + rng.normal(0, sigma, img.shape), 0, 255).astype(np.uint8)
    r = rng.random(img.shape)
    noisy[r < sp / 2] = 0
    noisy[r > 1 - sp / 2] = 255
    return noisy


def sobel_edges(gray):
    gx = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
    gy = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
    mag = cv2.magnitude(gx, gy)
    mag8 = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    return gx, gy, mag, mag8


def edge_scores(edges, ref, tol=2):
    """Precision / recall / F1 of an edge map vs reference, with pixel tolerance."""
    k = np.ones((2 * tol + 1, 2 * tol + 1), np.uint8)
    ref_d, edg_d = cv2.dilate(ref, k), cv2.dilate(edges, k)
    n_e, n_r = np.count_nonzero(edges), np.count_nonzero(ref)
    p = np.count_nonzero((edges > 0) & (ref_d > 0)) / max(n_e, 1)
    r = np.count_nonzero((ref > 0) & (edg_d > 0)) / max(n_r, 1)
    f1 = 2 * p * r / max(p + r, 1e-9)
    return p, r, f1


def tune_canny(gray, ref, grid=((20, 60), (30, 90), (50, 150), (70, 200), (100, 200))):
    best = None
    for lo, hi in grid:
        f1 = edge_scores(cv2.Canny(gray, lo, hi), ref)[2]
        if best is None or f1 > best[2]:
            best = (lo, hi, f1)
    return best[:2]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", default=None, help="X-ray / CT image")
    parser.add_argument("--no-noise", action="store_true",
                        help="do not add synthetic noise (image already noisy)")
    parser.add_argument("--sigma", type=float, default=18)
    args, _ = parser.parse_known_args()

    # 1. Load grayscale
    if args.image and os.path.exists(args.image):
        clean = cv2.imread(args.image, cv2.IMREAD_GRAYSCALE)
    else:
        print("[i] No scan supplied -> using synthetic phantom")
        clean = make_phantom()
    noisy = clean if args.no_noise else add_noise(clean, sigma=args.sigma)

    # 2. Filters
    variants = {
        "No filter": noisy,
        "Gaussian 5x5": cv2.GaussianBlur(noisy, (5, 5), 0),
        "Median 5": cv2.medianBlur(noisy, 5),
    }

    # Reference edges from the clean image (ground-truth proxy)
    ref_edges = cv2.Canny(clean, 50, 150)

    rows, plots = [], []
    for name, img in variants.items():
        gx, gy, mag, mag8 = sobel_edges(img)                     # 3. Sobel
        lo, hi = tune_canny(img, ref_edges)                      # 4. tuned Canny
        canny = cv2.Canny(img, lo, hi)
        p, r, f1 = edge_scores(canny, ref_edges)
        rows.append({
            "filter": name,
            "PSNR_dB": round(cv2.PSNR(clean, img), 2),
            "sharpness_LapVar": round(cv2.Laplacian(img, cv2.CV_64F).var(), 1),
            "sobel_mean_mag": round(float(mag.mean()), 2),
            "canny_T_low": lo, "canny_T_high": hi,
            "canny_edge_px": int(np.count_nonzero(canny)),
            "precision": round(p, 3), "recall": round(r, 3), "F1": round(f1, 3),
        })
        plots.append((name, img, mag8, canny))

    # Table
    keys = list(rows[0].keys())
    print("\n=== Quantitative comparison (edges vs clean-image reference) ===")
    print(" | ".join(f"{k:>16}" for k in keys))
    for r in rows:
        print(" | ".join(f"{str(r[k]):>16}" for k in keys))
    csv_path = os.path.join(OUT_DIR, "task3_comparison.csv")
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print("Saved:", csv_path)

    # Plot
    fig, axes = plt.subplots(len(plots) + 1, 3, figsize=(13, 16))
    axes[0, 0].imshow(clean, cmap="gray"); axes[0, 0].set_title("Clean / original")
    axes[0, 1].imshow(noisy, cmap="gray"); axes[0, 1].set_title("Noisy input")
    axes[0, 2].imshow(ref_edges, cmap="gray"); axes[0, 2].set_title("Reference Canny (clean)")
    for i, (name, img, mag8, canny) in enumerate(plots, start=1):
        axes[i, 0].imshow(img, cmap="gray"); axes[i, 0].set_title(f"{name}")
        axes[i, 1].imshow(mag8, cmap="gray"); axes[i, 1].set_title(f"Sobel magnitude - {name}")
        axes[i, 2].imshow(canny, cmap="gray")
        axes[i, 2].set_title(f"Canny ({rows[i-1]['canny_T_low']},{rows[i-1]['canny_T_high']}) "
                             f"F1={rows[i-1]['F1']}")
    for ax in axes.ravel():
        ax.set_xticks([]); ax.set_yticks([])
    fig.suptitle("Task 3: Noise reduction & edge detection", fontsize=14)
    plt.tight_layout()
    out = os.path.join(OUT_DIR, "task3_result.png")
    plt.savefig(out, dpi=110)
    print("Saved:", out)
    plt.show()


if __name__ == "__main__":
    main()
