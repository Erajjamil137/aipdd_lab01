"""Task 8 - Edge-triggered webcam surveillance with snapshot + event logging.

When a priority class (default: person, cell phone) is seen with conf > 0.65:
  * snapshot  -> alerts/YYYYMMDD_HHMMSS.jpg
  * log row   -> events.log  (Timestamp, Class, Confidence, x1, y1, x2, y2)
  * on-screen red border + "LOGGING EVENT" indicator
Keys: q = quit
"""
import argparse
import csv
import os
import time
from datetime import datetime

import cv2
from ultralytics import YOLO

from live_detection import open_capture, draw_fps

ALERT_DIR = "alerts"
LOG_FILE = "events.log"
LOG_HEADER = ["timestamp", "class_name", "confidence", "x1", "y1", "x2", "y2"]


def log_events(rows):
    new = not os.path.exists(LOG_FILE) or os.path.getsize(LOG_FILE) == 0
    with open(LOG_FILE, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(LOG_HEADER)
        w.writerows(rows)


def unique_snapshot_path(stamp):
    path = os.path.join(ALERT_DIR, f"{stamp}.jpg")
    n = 1
    while os.path.exists(path):                   # never overwrite
        path = os.path.join(ALERT_DIR, f"{stamp}_{n}.jpg")
        n += 1
    return path


def run(source, model_path, targets, conf_thr, cooldown):
    os.makedirs(ALERT_DIR, exist_ok=True)
    model = YOLO(model_path)
    cap = open_capture(source)
    fps, prev = 0.0, time.perf_counter()
    last_log, indicator_until = 0.0, 0.0
    try:
        while True:
            ok, frame = cap.read()
            if not ok:
                break
            res = model.predict(frame, conf=conf_thr, verbose=False)[0]
            view = res.plot()

            # collect high-priority detections above threshold
            hits = []
            for b in res.boxes:
                name, conf = res.names[int(b.cls[0])], float(b.conf[0])
                if name in targets and conf > conf_thr:
                    x1, y1, x2, y2 = (int(v) for v in b.xyxy[0].tolist())
                    hits.append((name, conf, x1, y1, x2, y2))

            now = time.time()
            if hits and now - last_log >= cooldown:     # cooldown avoids log spam
                stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                cv2.imwrite(unique_snapshot_path(stamp), view)
                ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                log_events([[ts, n, f"{c:.2f}", x1, y1, x2, y2] for n, c, x1, y1, x2, y2 in hits])
                print(f"[{ts}] logged {len(hits)} event(s): {[h[0] for h in hits]}")
                last_log, indicator_until = now, now + 1.0

            # visual indicator while / right after logging
            if now < indicator_until:
                cv2.rectangle(view, (0, 0), (view.shape[1] - 1, view.shape[0] - 1), (0, 0, 255), 8)
                cv2.putText(view, "REC - LOGGING EVENT", (10, view.shape[0] - 15),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2, cv2.LINE_AA)

            t = time.perf_counter()
            fps = 1 / max(t - prev, 1e-6) if fps == 0 else 0.9 * fps + 0.1 / max(t - prev, 1e-6)
            prev = t
            draw_fps(view, fps)

            cv2.imshow("Surveillance (q=quit)", view)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        cap.release()
        cv2.destroyAllWindows()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default="0", help="webcam index or video file")
    parser.add_argument("--model", default="yolov8n.pt")
    parser.add_argument("--targets", nargs="+", default=["person", "cell phone"])
    parser.add_argument("--conf", type=float, default=0.65)
    parser.add_argument("--cooldown", type=float, default=2.0, help="seconds between logs")
    args = parser.parse_args()
    run(args.source, args.model, set(args.targets), args.conf, args.cooldown)


if __name__ == "__main__":
    main()
