"""Builds LAB03_Tasks1-6.ipynb from the task scripts (run once: python build_notebook.py)."""
import nbformat as nbf

files = [("Task 1: Traffic preprocessing", "task1_preprocessing.py"),
         ("Task 2: Defect detection", "task2_defect_detection.py"),
         ("Task 3: Medical edges", "task3_medical_edges.py"),
         ("Task 4: YOLO benchmark", "task4_yolo_benchmark.py"),
         ("Task 5: Retail inventory", "task5_retail_inventory.py"),
         ("Task 6: ROI intrusion", "task6_roi_intrusion.py")]
nb = nbf.v4.new_notebook()
nb.cells.append(nbf.v4.new_markdown_cell("# AI-316 Lab 03 - Computer Vision Prototyping\nRun `pip install -r requirements.txt` first. Put `utils.py` in the same folder."))
for title, f in files:
    nb.cells.append(nbf.v4.new_markdown_cell(f"## {title}"))
    nb.cells.append(nbf.v4.new_code_cell("%matplotlib inline\n" + open(f).read()))
nbf.write(nb, "LAB03_Tasks1-6.ipynb")
print("written")
