"""Task 4 - YOLOv8n vs YOLOv8m benchmarking (latency, class counts, confidence)."""
import argparse
import csv
import os
import time
from collections import Counter

import cv2
import matplotlib.pyplot as plt
import numpy as np
from ultralytics import YOLO

from utils import OUT_DIR, load_image


def detect(model, img, conf=0.25, runs=5):
    """Warm-up once, then average latency over `runs`; return detections of last run."""
    model.predict(img, conf=conf, verbose=False)  # warm-up (not timed)
    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        res = model.predict(img, conf=conf, verbose=False)[0]
        times.append((time.perf_counter() - t0) * 1000)

    dets = []
    for b in res.boxes:
        x1, y1, x2, y2 = (int(v) for v in b.xyxy[0].tolist())
        cid = int(b.cls[0])
        dets.append({"box": (x1, y1, x2, y2), "conf": float(b.conf[0]),
                     "cls_id": cid, "label": res.names[cid]})
    return dets, float(np.mean(times))


def draw(img, dets, color, title):
    out = img.copy()
    for d in dets:
        x1, y1, x2, y2 = d["box"]
        cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)
        txt = f"{d['label']} {d['conf']:.2f}"
        (tw, th), _ = cv2.getTextSize(txt, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        cv2.rectangle(out, (x1, max(0, y1 - th - 6)), (x1 + tw + 4, y1), color, -1)
        cv2.putText(out, txt, (x1 + 2, max(th, y1 - 4)), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, (255, 255, 255), 1, cv2.LINE_AA)
    cv2.rectangle(out, (0, 0), (out.shape[1], 30), (0, 0, 0), -1)
    cv2.putText(out, title, (8, 21), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2, cv2.LINE_AA)
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--image", default=None, help="test image from your dataset")
    parser.add_argument("--models", nargs=2, default=["yolov8n.pt", "yolov8m.pt"])
    parser.add_argument("--conf", type=float, default=0.25)
    parser.add_argument("--runs", type=int, default=5)
    args, _ = parser.parse_known_args()

    img = load_image(args.image, fallback="bus.jpg")
    colors = [(0, 200, 0), (0, 0, 230)]
    results, rendered = [], []

    for name, color in zip(args.models, colors):
        model = YOLO(name)                               # 1. load
        dets, ms = detect(model, img, args.conf, args.runs)   # 2-3. infer + extract
        counts = Counter(d["label"] for d in dets)
        avg_conf = float(np.mean([d["conf"] for d in dets])) if dets else 0.0
        results.append({"model": name, "latency_ms": round(ms, 1),
                        "detections": len(dets), "unique_classes": len(counts),
                        "avg_confidence": round(avg_conf, 3),
                        "class_counts": dict(counts)})
        print(f"\n--- {name} ---")
        for d in dets:
            print(f"  {d['label']:<12} conf={d['conf']:.2f} box={d['box']}")
        rendered.append(draw(img, dets, color, f"{name} | {ms:.1f} ms | {len(dets)} objs"))  # 4.

    # Comparison table
    print("\n=== Comparison table ===")
    hdr = f"{'Model':<12}{'Latency (ms)':>14}{'Detections':>12}{'Classes':>9}{'Avg conf':>10}  Class counts"
    print(hdr)
    print("-" * len(hdr))
    for r in results:
        print(f"{r['model']:<12}{r['latency_ms']:>14}{r['detections']:>12}"
              f"{r['unique_classes']:>9}{r['avg_confidence']:>10}  {r['class_counts']}")

    csv_path = os.path.join(OUT_DIR, "task4_comparison.csv")
    with open(csv_path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=results[0].keys())
        w.writeheader()
        w.writerows(results)

    # Dual visual output
    fig, axes = plt.subplots(1, 2, figsize=(15, 8))
    for ax, im, r in zip(axes, rendered, results):
        ax.imshow(cv2.cvtColor(im, cv2.COLOR_BGR2RGB))
        ax.set_title(f"{r['model']}  ({r['latency_ms']} ms, avg conf {r['avg_confidence']})")
        ax.axis("off")
    plt.tight_layout()
    out = os.path.join(OUT_DIR, "task4_result.png")
    plt.savefig(out, dpi=120)
    print("Saved:", out, "and", csv_path)
    plt.show()


if __name__ == "__main__":
    main()
